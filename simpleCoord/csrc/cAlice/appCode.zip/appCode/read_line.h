ssize_t readLine(int fd, void *buffer, size_t n);
