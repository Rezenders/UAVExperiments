#define R 6371.0 //radius of earth in km
#define PI 3.14159265

double distance(double p1[], double p2[]);
double to_radians(double degrees);
